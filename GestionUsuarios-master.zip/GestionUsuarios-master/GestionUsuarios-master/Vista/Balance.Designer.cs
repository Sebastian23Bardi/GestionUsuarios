﻿namespace Vista
{
    partial class Balance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Balance));
            dgvProductos = new DataGridView();
            lbl_balances = new Label();
            dtpFechaBalance = new DateTimePicker();
            btnEliminar = new Button();
            btnEditar = new Button();
            lblEtiquetaTotal = new Label();
            lblTotal = new Label();
            panel1 = new Panel();
            btnAgregar = new Button();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            btn_atras = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvProductos).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // dgvProductos
            // 
            dgvProductos.AllowUserToAddRows = false;
            dgvProductos.AllowUserToResizeColumns = false;
            dgvProductos.BackgroundColor = SystemColors.Window;
            dgvProductos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvProductos.GridColor = SystemColors.ControlDark;
            dgvProductos.Location = new Point(29, 51);
            dgvProductos.Margin = new Padding(3, 2, 3, 2);
            dgvProductos.MultiSelect = false;
            dgvProductos.Name = "dgvProductos";
            dgvProductos.RowHeadersVisible = false;
            dgvProductos.RowHeadersWidth = 51;
            dgvProductos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvProductos.Size = new Size(360, 300);
            dgvProductos.TabIndex = 0;
            dgvProductos.CellContentClick += dgvProductos_CellContentClick;
            // 
            // lbl_balances
            // 
            lbl_balances.AutoSize = true;
            lbl_balances.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_balances.Location = new Point(470, 55);
            lbl_balances.Name = "lbl_balances";
            lbl_balances.Size = new Size(76, 15);
            lbl_balances.TabIndex = 1;
            lbl_balances.Text = "Tus Balances";
            // 
            // dtpFechaBalance
            // 
            dtpFechaBalance.CustomFormat = "dd/MM/yyyy";
            dtpFechaBalance.Format = DateTimePickerFormat.Custom;
            dtpFechaBalance.Location = new Point(428, 72);
            dtpFechaBalance.Margin = new Padding(3, 2, 3, 2);
            dtpFechaBalance.Name = "dtpFechaBalance";
            dtpFechaBalance.Size = new Size(170, 23);
            dtpFechaBalance.TabIndex = 2;
            // 
            // btnEliminar
            // 
            btnEliminar.BackColor = Color.FromArgb(92, 29, 36);
            btnEliminar.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEliminar.ForeColor = SystemColors.Window;
            btnEliminar.Location = new Point(456, 195);
            btnEliminar.Margin = new Padding(3, 2, 3, 2);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(114, 61);
            btnEliminar.TabIndex = 4;
            btnEliminar.Text = "Eliminar producto";
            btnEliminar.UseVisualStyleBackColor = false;
            // 
            // btnEditar
            // 
            btnEditar.BackColor = Color.FromArgb(92, 29, 36);
            btnEditar.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEditar.ForeColor = SystemColors.Window;
            btnEditar.Location = new Point(456, 280);
            btnEditar.Margin = new Padding(3, 2, 3, 2);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(114, 61);
            btnEditar.TabIndex = 5;
            btnEditar.Text = "Editar producto";
            btnEditar.UseVisualStyleBackColor = false;
            // 
            // lblEtiquetaTotal
            // 
            lblEtiquetaTotal.AutoSize = true;
            lblEtiquetaTotal.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblEtiquetaTotal.Location = new Point(0, 3);
            lblEtiquetaTotal.Name = "lblEtiquetaTotal";
            lblEtiquetaTotal.Size = new Size(75, 15);
            lblEtiquetaTotal.TabIndex = 6;
            lblEtiquetaTotal.Text = "Balance total";
            // 
            // lblTotal
            // 
            lblTotal.Location = new Point(280, 3);
            lblTotal.Name = "lblTotal";
            lblTotal.Size = new Size(79, 19);
            lblTotal.TabIndex = 7;
            lblTotal.Text = "0.00";
            lblTotal.TextAlign = ContentAlignment.MiddleRight;
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.Window;
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(lblEtiquetaTotal);
            panel1.Controls.Add(lblTotal);
            panel1.Location = new Point(29, 327);
            panel1.Margin = new Padding(3, 2, 3, 2);
            panel1.Name = "panel1";
            panel1.Size = new Size(360, 24);
            panel1.TabIndex = 8;
            // 
            // btnAgregar
            // 
            btnAgregar.BackColor = Color.FromArgb(92, 29, 36);
            btnAgregar.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAgregar.ForeColor = SystemColors.Window;
            btnAgregar.Location = new Point(456, 110);
            btnAgregar.Margin = new Padding(3, 2, 3, 2);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(114, 61);
            btnAgregar.TabIndex = 3;
            btnAgregar.Text = "Catalogo";
            btnAgregar.UseVisualStyleBackColor = false;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(-2, -1);
            pictureBox1.Margin = new Padding(3, 2, 3, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(648, 38);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 9;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(92, 29, 36);
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.Window;
            label1.Location = new Point(163, 7);
            label1.Name = "label1";
            label1.Size = new Size(306, 21);
            label1.TabIndex = 10;
            label1.Text = "BALANCE                                                        ";
            // 
            // btn_atras
            // 
            btn_atras.Location = new Point(551, 7);
            btn_atras.Margin = new Padding(3, 2, 3, 2);
            btn_atras.Name = "btn_atras";
            btn_atras.Size = new Size(82, 22);
            btn_atras.TabIndex = 11;
            btn_atras.Text = "Atrás";
            btn_atras.UseVisualStyleBackColor = true;
            btn_atras.Click += btn_atras_Click;
            // 
            // Balance
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientInactiveCaption;
            ClientSize = new Size(641, 368);
            Controls.Add(btn_atras);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Controls.Add(panel1);
            Controls.Add(btnEditar);
            Controls.Add(btnEliminar);
            Controls.Add(btnAgregar);
            Controls.Add(dtpFechaBalance);
            Controls.Add(lbl_balances);
            Controls.Add(dgvProductos);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 2, 3, 2);
            Name = "Balance";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Stock";
            ((System.ComponentModel.ISupportInitialize)dgvProductos).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvProductos;
        private Label lbl_balances;
        private DateTimePicker dtpFechaBalance;
        private Button btnEliminar;
        private Button btnEditar;
        private Label lblEtiquetaTotal;
        private Label lblTotal;
        private Panel panel1;
        private Button btnAgregar;
        private PictureBox pictureBox1;
        private Label label1;
        private Button btn_atras;
    }
}