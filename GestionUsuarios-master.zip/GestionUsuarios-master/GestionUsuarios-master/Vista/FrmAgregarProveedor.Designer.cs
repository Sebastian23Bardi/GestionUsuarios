﻿namespace Vista
{
    partial class FrmAgregarProveedor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmAgregarProveedor));
            lblNombre = new Label();
            lblTeléfono = new Label();
            lblCorreo = new Label();
            lblAliasBancario = new Label();
            txtNombre = new TextBox();
            txtTelefono = new TextBox();
            txtCorreo = new TextBox();
            txtAlias = new TextBox();
            btnGuardar = new Button();
            panel1 = new Panel();
            button1 = new Button();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // lblNombre
            // 
            lblNombre.AutoSize = true;
            lblNombre.Font = new Font("Segoe UI", 10.2F);
            lblNombre.Location = new Point(64, 100);
            lblNombre.Name = "lblNombre";
            lblNombre.Size = new Size(62, 19);
            lblNombre.TabIndex = 0;
            lblNombre.Text = "Nombre:";
            // 
            // lblTeléfono
            // 
            lblTeléfono.AutoSize = true;
            lblTeléfono.Font = new Font("Segoe UI", 10.2F);
            lblTeléfono.Location = new Point(64, 153);
            lblTeléfono.Name = "lblTeléfono";
            lblTeléfono.Size = new Size(63, 19);
            lblTeléfono.TabIndex = 1;
            lblTeléfono.Text = "Teléfono:";
            // 
            // lblCorreo
            // 
            lblCorreo.AutoSize = true;
            lblCorreo.Font = new Font("Segoe UI", 10.2F);
            lblCorreo.Location = new Point(64, 203);
            lblCorreo.Name = "lblCorreo";
            lblCorreo.Size = new Size(54, 19);
            lblCorreo.TabIndex = 2;
            lblCorreo.Text = "Correo:";
            // 
            // lblAliasBancario
            // 
            lblAliasBancario.AutoSize = true;
            lblAliasBancario.Font = new Font("Segoe UI", 10.2F);
            lblAliasBancario.Location = new Point(40, 254);
            lblAliasBancario.Name = "lblAliasBancario";
            lblAliasBancario.Size = new Size(96, 19);
            lblAliasBancario.TabIndex = 3;
            lblAliasBancario.Text = "Alias Bancario:";
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(177, 100);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(205, 26);
            txtNombre.TabIndex = 4;
            // 
            // txtTelefono
            // 
            txtTelefono.Location = new Point(177, 149);
            txtTelefono.Name = "txtTelefono";
            txtTelefono.Size = new Size(205, 26);
            txtTelefono.TabIndex = 5;
            // 
            // txtCorreo
            // 
            txtCorreo.Location = new Point(177, 200);
            txtCorreo.Name = "txtCorreo";
            txtCorreo.Size = new Size(205, 26);
            txtCorreo.TabIndex = 6;
            // 
            // txtAlias
            // 
            txtAlias.Location = new Point(177, 250);
            txtAlias.Name = "txtAlias";
            txtAlias.Size = new Size(205, 26);
            txtAlias.TabIndex = 7;
            // 
            // btnGuardar
            // 
            btnGuardar.BackColor = Color.FromArgb(92, 29, 36);
            btnGuardar.FlatStyle = FlatStyle.Flat;
            btnGuardar.ForeColor = SystemColors.Window;
            btnGuardar.Location = new Point(210, 308);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(106, 33);
            btnGuardar.TabIndex = 8;
            btnGuardar.Text = "Guardar";
            btnGuardar.UseVisualStyleBackColor = false;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(92, 29, 36);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(-7, -2);
            panel1.Name = "panel1";
            panel1.Size = new Size(575, 67);
            panel1.TabIndex = 10;
            // 
            // button1
            // 
            button1.Location = new Point(412, 20);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 2;
            button1.Text = "Atrás";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(3, -3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(130, 70);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.Window;
            label1.Location = new Point(130, 20);
            label1.Name = "label1";
            label1.Size = new Size(259, 25);
            label1.TabIndex = 0;
            label1.Text = "Regest | Agregar Proveedor";
            label1.Click += label1_Click;
            // 
            // FrmAgregarProveedor
            // 
            AutoScaleDimensions = new SizeF(8F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientInactiveCaption;
            ClientSize = new Size(511, 363);
            Controls.Add(panel1);
            Controls.Add(btnGuardar);
            Controls.Add(txtAlias);
            Controls.Add(txtCorreo);
            Controls.Add(txtTelefono);
            Controls.Add(txtNombre);
            Controls.Add(lblAliasBancario);
            Controls.Add(lblCorreo);
            Controls.Add(lblTeléfono);
            Controls.Add(lblNombre);
            Font = new Font("Segoe UI", 10.2F);
            FormBorderStyle = FormBorderStyle.None;
            Name = "FrmAgregarProveedor";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FrmAgregarProveedor";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNombre;
        private Label lblTeléfono;
        private Label lblCorreo;
        private Label lblAliasBancario;
        private TextBox txtNombre;
        private TextBox txtTelefono;
        private TextBox txtCorreo;
        private TextBox txtAlias;
        private Button btnGuardar;
        private Panel panel1;
        private Label label1;
        private PictureBox pictureBox1;
        private Button button1;
    }
}