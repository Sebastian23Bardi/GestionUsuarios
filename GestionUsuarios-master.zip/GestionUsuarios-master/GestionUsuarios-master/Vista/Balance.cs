﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vista
{
    public partial class Balance : Form
    {
        private DataTable tablaProductos;
        public Balance()
        {
            InitializeComponent();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {

            CrearCatalogo catalogo = new CrearCatalogo();
            catalogo.Show();
            this.Close();
        }

        private void dgvProductos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btn_atras_Click(object sender, EventArgs e)
        {
            MenuEmpresa menu = new MenuEmpresa();
            menu.Show();
            this.Close();


        }
    }


}
