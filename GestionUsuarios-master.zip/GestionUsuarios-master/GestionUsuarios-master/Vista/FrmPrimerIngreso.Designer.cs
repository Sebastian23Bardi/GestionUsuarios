﻿namespace Recuperacion_de_contraseña
{
    partial class FrmPrimerIngreso
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            NuevaContra = new Label();
            ConfirmarContraseña = new Label();
            txtContraseña1 = new TextBox();
            txtContraseña2 = new TextBox();
            preguntas = new Label();
            btnCambiarContra = new Button();
            btnrespuesta = new Button();
            txtrespuesta = new TextBox();
            panel2 = new Panel();
            chkPregunta3 = new RadioButton();
            chkPregunta2 = new RadioButton();
            chkPregunta1 = new RadioButton();
            label5 = new Label();
            ProgressBar = new ProgressBar();
            label1 = new Label();
            cmbPreguntas = new ComboBox();
            panel1 = new Panel();
            chkMostrarContra = new CheckBox();
            lblpaso1 = new Label();
            panel3 = new Panel();
            button1 = new Button();
            label2 = new Label();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            panel3.SuspendLayout();
            SuspendLayout();
            // 
            // NuevaContra
            // 
            NuevaContra.AutoSize = true;
            NuevaContra.Location = new Point(4, 25);
            NuevaContra.Name = "NuevaContra";
            NuevaContra.Size = new Size(107, 15);
            NuevaContra.TabIndex = 0;
            NuevaContra.Text = "Nueva Contraseña:";
            // 
            // ConfirmarContraseña
            // 
            ConfirmarContraseña.AutoSize = true;
            ConfirmarContraseña.Location = new Point(4, 64);
            ConfirmarContraseña.Name = "ConfirmarContraseña";
            ConfirmarContraseña.Size = new Size(127, 15);
            ConfirmarContraseña.TabIndex = 1;
            ConfirmarContraseña.Text = "Confirmar Contraseña:";
            // 
            // txtContraseña1
            // 
            txtContraseña1.BorderStyle = BorderStyle.FixedSingle;
            txtContraseña1.Enabled = false;
            txtContraseña1.Location = new Point(146, 23);
            txtContraseña1.Margin = new Padding(3, 2, 3, 2);
            txtContraseña1.Name = "txtContraseña1";
            txtContraseña1.Size = new Size(188, 23);
            txtContraseña1.TabIndex = 3;
            txtContraseña1.UseSystemPasswordChar = true;
            // 
            // txtContraseña2
            // 
            txtContraseña2.BorderStyle = BorderStyle.FixedSingle;
            txtContraseña2.Enabled = false;
            txtContraseña2.Location = new Point(146, 62);
            txtContraseña2.Margin = new Padding(3, 2, 3, 2);
            txtContraseña2.Name = "txtContraseña2";
            txtContraseña2.Size = new Size(188, 23);
            txtContraseña2.TabIndex = 4;
            txtContraseña2.UseSystemPasswordChar = true;
            // 
            // preguntas
            // 
            preguntas.AutoSize = true;
            preguntas.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            preguntas.Location = new Point(28, 266);
            preguntas.Name = "preguntas";
            preguntas.Size = new Size(189, 15);
            preguntas.TabIndex = 5;
            preguntas.Text = "Paso 2: Creá tu nueva contraseña";
            preguntas.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // btnCambiarContra
            // 
            btnCambiarContra.BackColor = Color.FromArgb(92, 29, 36);
            btnCambiarContra.Enabled = false;
            btnCambiarContra.FlatStyle = FlatStyle.Popup;
            btnCambiarContra.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCambiarContra.ForeColor = SystemColors.ControlLightLight;
            btnCambiarContra.Location = new Point(340, 28);
            btnCambiarContra.Margin = new Padding(3, 2, 3, 2);
            btnCambiarContra.Name = "btnCambiarContra";
            btnCambiarContra.Size = new Size(85, 50);
            btnCambiarContra.TabIndex = 13;
            btnCambiarContra.Text = "Confirmar";
            btnCambiarContra.UseVisualStyleBackColor = false;
            btnCambiarContra.Click += btnCambiarContra_Click;
            // 
            // btnrespuesta
            // 
            btnrespuesta.BackColor = Color.FromArgb(92, 29, 36);
            btnrespuesta.FlatStyle = FlatStyle.Popup;
            btnrespuesta.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnrespuesta.ForeColor = Color.White;
            btnrespuesta.Location = new Point(136, 165);
            btnrespuesta.Margin = new Padding(3, 2, 3, 2);
            btnrespuesta.Name = "btnrespuesta";
            btnrespuesta.Size = new Size(145, 22);
            btnrespuesta.TabIndex = 18;
            btnrespuesta.Text = "Guardar respuesta";
            btnrespuesta.UseVisualStyleBackColor = false;
            btnrespuesta.Click += btnrespuesta_Click;
            // 
            // txtrespuesta
            // 
            txtrespuesta.Location = new Point(3, 78);
            txtrespuesta.Margin = new Padding(3, 2, 3, 2);
            txtrespuesta.Name = "txtrespuesta";
            txtrespuesta.Size = new Size(292, 23);
            txtrespuesta.TabIndex = 17;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.InactiveCaption;
            panel2.Controls.Add(chkPregunta3);
            panel2.Controls.Add(chkPregunta2);
            panel2.Controls.Add(chkPregunta1);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(btnrespuesta);
            panel2.Controls.Add(ProgressBar);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(txtrespuesta);
            panel2.Controls.Add(cmbPreguntas);
            panel2.Location = new Point(27, 65);
            panel2.Margin = new Padding(3, 2, 3, 2);
            panel2.Name = "panel2";
            panel2.Size = new Size(441, 190);
            panel2.TabIndex = 19;
            // 
            // chkPregunta3
            // 
            chkPregunta3.AutoCheck = false;
            chkPregunta3.AutoSize = true;
            chkPregunta3.BackColor = SystemColors.InactiveCaption;
            chkPregunta3.Enabled = false;
            chkPregunta3.ForeColor = SystemColors.GrayText;
            chkPregunta3.Location = new Point(246, 136);
            chkPregunta3.Margin = new Padding(3, 2, 3, 2);
            chkPregunta3.Name = "chkPregunta3";
            chkPregunta3.Size = new Size(82, 19);
            chkPregunta3.TabIndex = 33;
            chkPregunta3.Text = "Pregunta 3";
            chkPregunta3.UseVisualStyleBackColor = false;
            // 
            // chkPregunta2
            // 
            chkPregunta2.AutoCheck = false;
            chkPregunta2.AutoSize = true;
            chkPregunta2.Enabled = false;
            chkPregunta2.ForeColor = SystemColors.GrayText;
            chkPregunta2.Location = new Point(136, 136);
            chkPregunta2.Margin = new Padding(3, 2, 3, 2);
            chkPregunta2.Name = "chkPregunta2";
            chkPregunta2.Size = new Size(82, 19);
            chkPregunta2.TabIndex = 32;
            chkPregunta2.Text = "Pregunta 2";
            chkPregunta2.UseVisualStyleBackColor = true;
            // 
            // chkPregunta1
            // 
            chkPregunta1.AutoCheck = false;
            chkPregunta1.AutoSize = true;
            chkPregunta1.Enabled = false;
            chkPregunta1.ForeColor = SystemColors.GrayText;
            chkPregunta1.Location = new Point(17, 136);
            chkPregunta1.Margin = new Padding(3, 2, 3, 2);
            chkPregunta1.Name = "chkPregunta1";
            chkPregunta1.Size = new Size(82, 19);
            chkPregunta1.TabIndex = 31;
            chkPregunta1.Text = "Pregunta 1";
            chkPregunta1.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(4, 14);
            label5.Name = "label5";
            label5.Size = new Size(63, 15);
            label5.TabIndex = 27;
            label5.Text = "Preguntas:";
            // 
            // ProgressBar
            // 
            ProgressBar.Location = new Point(3, 103);
            ProgressBar.Margin = new Padding(3, 2, 3, 2);
            ProgressBar.Maximum = 3;
            ProgressBar.Name = "ProgressBar";
            ProgressBar.Size = new Size(351, 22);
            ProgressBar.Step = 1;
            ProgressBar.TabIndex = 23;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(3, 55);
            label1.Name = "label1";
            label1.Size = new Size(63, 15);
            label1.TabIndex = 22;
            label1.Text = "Respuesta:";
            // 
            // cmbPreguntas
            // 
            cmbPreguntas.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbPreguntas.FormattingEnabled = true;
            cmbPreguntas.Location = new Point(3, 31);
            cmbPreguntas.Margin = new Padding(3, 2, 3, 2);
            cmbPreguntas.Name = "cmbPreguntas";
            cmbPreguntas.Size = new Size(351, 23);
            cmbPreguntas.TabIndex = 20;
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.InactiveCaption;
            panel1.Controls.Add(chkMostrarContra);
            panel1.Controls.Add(NuevaContra);
            panel1.Controls.Add(ConfirmarContraseña);
            panel1.Controls.Add(txtContraseña1);
            panel1.Controls.Add(btnCambiarContra);
            panel1.Controls.Add(txtContraseña2);
            panel1.Location = new Point(27, 295);
            panel1.Margin = new Padding(3, 2, 3, 2);
            panel1.Name = "panel1";
            panel1.Size = new Size(441, 118);
            panel1.TabIndex = 20;
            // 
            // chkMostrarContra
            // 
            chkMostrarContra.AutoSize = true;
            chkMostrarContra.Enabled = false;
            chkMostrarContra.Location = new Point(150, 92);
            chkMostrarContra.Margin = new Padding(3, 2, 3, 2);
            chkMostrarContra.Name = "chkMostrarContra";
            chkMostrarContra.Size = new Size(130, 19);
            chkMostrarContra.TabIndex = 14;
            chkMostrarContra.Text = "Mostrar Contraseña";
            chkMostrarContra.UseVisualStyleBackColor = true;
            chkMostrarContra.CheckedChanged += chkMostrarContra_CheckedChanged;
            // 
            // lblpaso1
            // 
            lblpaso1.AutoSize = true;
            lblpaso1.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblpaso1.Location = new Point(32, 41);
            lblpaso1.Name = "lblpaso1";
            lblpaso1.Size = new Size(285, 15);
            lblpaso1.TabIndex = 21;
            lblpaso1.Text = "Paso 1: Configurá tus preguntas de seguridad (0/3)";
            lblpaso1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(92, 29, 36);
            panel3.Controls.Add(button1);
            panel3.Controls.Add(label2);
            panel3.Location = new Point(-3, -26);
            panel3.Margin = new Padding(3, 2, 3, 2);
            panel3.Name = "panel3";
            panel3.Size = new Size(504, 56);
            panel3.TabIndex = 22;
            // 
            // button1
            // 
            button1.Location = new Point(407, 28);
            button1.Margin = new Padding(3, 2, 3, 2);
            button1.Name = "button1";
            button1.Size = new Size(82, 22);
            button1.TabIndex = 1;
            button1.Text = "Atrás";
            button1.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.Window;
            label2.Location = new Point(3, 28);
            label2.Name = "label2";
            label2.Size = new Size(257, 30);
            label2.TabIndex = 0;
            label2.Text = "ReGest | Primer ingreso";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            label2.Click += label2_Click;
            // 
            // FrmPrimerIngreso
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientInactiveCaption;
            ClientSize = new Size(497, 425);
            Controls.Add(panel3);
            Controls.Add(lblpaso1);
            Controls.Add(panel1);
            Controls.Add(panel2);
            Controls.Add(preguntas);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 2, 3, 2);
            Name = "FrmPrimerIngreso";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Primer Ingreso";
            Load += FrmPrimerIngreso_Load;
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label NuevaContra;
        private Label ConfirmarContraseña;
        private TextBox txtContraseña1;
        private TextBox txtContraseña2;
        private Label preguntas;
        private Button btnCambiarContra;
        private Button btnrespuesta;
        private TextBox txtrespuesta;
        private Panel panel2;
        private Label label1;
        private ComboBox cmbPreguntas;
        private ProgressBar ProgressBar;
        private Panel panel1;
        private Label label5;
        private Label lblpaso1;
        private RadioButton chkPregunta3;
        private RadioButton chkPregunta2;
        private RadioButton chkPregunta1;
        private CheckBox chkMostrarContra;
        private Panel panel3;
        private Label label2;
        private Button button1;
    }
}
