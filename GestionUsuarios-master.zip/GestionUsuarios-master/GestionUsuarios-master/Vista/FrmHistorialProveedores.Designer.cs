﻿namespace Vista
{
    partial class FrmHistorialProveedores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle7 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmHistorialProveedores));
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            dgvHistorial = new DataGridView();
            lblBuscar = new Label();
            lblDesde = new Label();
            lblHasta = new Label();
            txtBuscar = new TextBox();
            dtpDesde = new DateTimePicker();
            dtpHasta = new DateTimePicker();
            btnFiltrar = new Button();
            btnLimpiar = new Button();
            flowLayoutPanel1 = new FlowLayoutPanel();
            pictureBox1 = new PictureBox();
            btnNuevaCompra = new Button();
            btn_Atras = new Button();
            btn_descargar = new Button();
            colFecha = new DataGridViewTextBoxColumn();
            colProveedor = new DataGridViewTextBoxColumn();
            colProducto = new DataGridViewTextBoxColumn();
            colKilos = new DataGridViewTextBoxColumn();
            colUnidades = new DataGridViewTextBoxColumn();
            colTotal = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)dgvHistorial).BeginInit();
            flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // dgvHistorial
            // 
            dgvHistorial.AllowUserToAddRows = false;
            dgvHistorial.AllowUserToResizeColumns = false;
            dgvHistorial.AllowUserToResizeRows = false;
            dgvHistorial.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvHistorial.BackgroundColor = Color.White;
            dgvHistorial.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvHistorial.Columns.AddRange(new DataGridViewColumn[] { colFecha, colProveedor, colProducto, colKilos, colUnidades, colTotal });
            dataGridViewCellStyle7.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = SystemColors.Window;
            dataGridViewCellStyle7.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle7.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle7.NullValue = null;
            dataGridViewCellStyle7.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = DataGridViewTriState.False;
            dgvHistorial.DefaultCellStyle = dataGridViewCellStyle7;
            dgvHistorial.Location = new Point(55, 142);
            dgvHistorial.Margin = new Padding(3, 2, 3, 2);
            dgvHistorial.Name = "dgvHistorial";
            dgvHistorial.ReadOnly = true;
            dgvHistorial.RowHeadersVisible = false;
            dgvHistorial.RowHeadersWidth = 51;
            dgvHistorial.ScrollBars = ScrollBars.Vertical;
            dgvHistorial.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvHistorial.Size = new Size(679, 244);
            dgvHistorial.TabIndex = 0;
            dgvHistorial.CellContentClick += dgvHistorial_CellContentClick;
            // 
            // lblBuscar
            // 
            lblBuscar.AutoSize = true;
            lblBuscar.Location = new Point(93, 73);
            lblBuscar.Name = "lblBuscar";
            lblBuscar.Size = new Size(45, 15);
            lblBuscar.TabIndex = 1;
            lblBuscar.Text = "Buscar:";
            // 
            // lblDesde
            // 
            lblDesde.AutoSize = true;
            lblDesde.Location = new Point(365, 73);
            lblDesde.Name = "lblDesde";
            lblDesde.Size = new Size(42, 15);
            lblDesde.TabIndex = 2;
            lblDesde.Text = "Desde:";
            // 
            // lblHasta
            // 
            lblHasta.AutoSize = true;
            lblHasta.Location = new Point(547, 73);
            lblHasta.Name = "lblHasta";
            lblHasta.Size = new Size(40, 15);
            lblHasta.TabIndex = 3;
            lblHasta.Text = "Hasta:";
            // 
            // txtBuscar
            // 
            txtBuscar.Location = new Point(147, 70);
            txtBuscar.Margin = new Padding(3, 2, 3, 2);
            txtBuscar.Name = "txtBuscar";
            txtBuscar.Size = new Size(169, 23);
            txtBuscar.TabIndex = 4;
            // 
            // dtpDesde
            // 
            dtpDesde.Format = DateTimePickerFormat.Short;
            dtpDesde.Location = new Point(418, 69);
            dtpDesde.Margin = new Padding(3, 2, 3, 2);
            dtpDesde.Name = "dtpDesde";
            dtpDesde.Size = new Size(109, 23);
            dtpDesde.TabIndex = 5;
            // 
            // dtpHasta
            // 
            dtpHasta.Format = DateTimePickerFormat.Short;
            dtpHasta.Location = new Point(596, 70);
            dtpHasta.Margin = new Padding(3, 2, 3, 2);
            dtpHasta.Name = "dtpHasta";
            dtpHasta.Size = new Size(112, 23);
            dtpHasta.TabIndex = 6;
            // 
            // btnFiltrar
            // 
            btnFiltrar.Location = new Point(92, 110);
            btnFiltrar.Margin = new Padding(3, 2, 3, 2);
            btnFiltrar.Name = "btnFiltrar";
            btnFiltrar.Size = new Size(82, 22);
            btnFiltrar.TabIndex = 7;
            btnFiltrar.Text = "Filtrar";
            btnFiltrar.UseVisualStyleBackColor = true;
            btnFiltrar.Click += btnFiltrar_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.Location = new Point(217, 110);
            btnLimpiar.Margin = new Padding(3, 2, 3, 2);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(82, 22);
            btnLimpiar.TabIndex = 8;
            btnLimpiar.Text = "Limpiar Filtros";
            btnLimpiar.UseVisualStyleBackColor = true;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.BackColor = Color.FromArgb(92, 29, 36);
            flowLayoutPanel1.Controls.Add(pictureBox1);
            flowLayoutPanel1.Dock = DockStyle.Top;
            flowLayoutPanel1.Location = new Point(0, 0);
            flowLayoutPanel1.Margin = new Padding(3, 2, 3, 2);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(815, 53);
            flowLayoutPanel1.TabIndex = 9;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(3, 2);
            pictureBox1.Margin = new Padding(3, 2, 3, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(802, 69);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // btnNuevaCompra
            // 
            btnNuevaCompra.Location = new Point(340, 110);
            btnNuevaCompra.Margin = new Padding(3, 2, 3, 2);
            btnNuevaCompra.Name = "btnNuevaCompra";
            btnNuevaCompra.Size = new Size(121, 22);
            btnNuevaCompra.TabIndex = 10;
            btnNuevaCompra.Text = "Nueva Compra";
            btnNuevaCompra.UseVisualStyleBackColor = true;
            btnNuevaCompra.Click += btnNuevaCompra_Click;
            // 
            // btn_Atras
            // 
            btn_Atras.Location = new Point(722, 10);
            btn_Atras.Margin = new Padding(3, 2, 3, 2);
            btn_Atras.Name = "btn_Atras";
            btn_Atras.Size = new Size(82, 22);
            btn_Atras.TabIndex = 11;
            btn_Atras.Text = "Atrás";
            btn_Atras.UseVisualStyleBackColor = true;
            btn_Atras.Click += btn_Atras_Click;
            // 
            // btn_descargar
            // 
            btn_descargar.Location = new Point(608, 109);
            btn_descargar.Name = "btn_descargar";
            btn_descargar.Size = new Size(126, 23);
            btn_descargar.TabIndex = 12;
            btn_descargar.Text = "Descargar Grilla";
            btn_descargar.UseVisualStyleBackColor = true;
            // 
            // colFecha
            // 
            colFecha.DataPropertyName = "Fecha";
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.Format = "dd/MM/yyyy";
            colFecha.DefaultCellStyle = dataGridViewCellStyle1;
            colFecha.FillWeight = 75F;
            colFecha.HeaderText = "Fecha";
            colFecha.MinimumWidth = 6;
            colFecha.Name = "colFecha";
            colFecha.ReadOnly = true;
            // 
            // colProveedor
            // 
            colProveedor.DataPropertyName = "Proveedor";
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            colProveedor.DefaultCellStyle = dataGridViewCellStyle2;
            colProveedor.FillWeight = 110F;
            colProveedor.HeaderText = "Proveedor";
            colProveedor.MinimumWidth = 6;
            colProveedor.Name = "colProveedor";
            colProveedor.ReadOnly = true;
            // 
            // colProducto
            // 
            colProducto.DataPropertyName = "Producto";
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            colProducto.DefaultCellStyle = dataGridViewCellStyle3;
            colProducto.FillWeight = 110F;
            colProducto.HeaderText = "Producto";
            colProducto.MinimumWidth = 6;
            colProducto.Name = "colProducto";
            colProducto.ReadOnly = true;
            // 
            // colKilos
            // 
            colKilos.DataPropertyName = "Cantidad";
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle4.Format = "N2";
            colKilos.DefaultCellStyle = dataGridViewCellStyle4;
            colKilos.FillWeight = 60F;
            colKilos.HeaderText = "Cantidad";
            colKilos.MinimumWidth = 6;
            colKilos.Name = "colKilos";
            colKilos.ReadOnly = true;
            // 
            // colUnidades
            // 
            colUnidades.DataPropertyName = "Precio";
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.Format = "C2";
            dataGridViewCellStyle5.NullValue = null;
            colUnidades.DefaultCellStyle = dataGridViewCellStyle5;
            colUnidades.FillWeight = 60F;
            colUnidades.HeaderText = "Precio";
            colUnidades.MinimumWidth = 6;
            colUnidades.Name = "colUnidades";
            colUnidades.ReadOnly = true;
            // 
            // colTotal
            // 
            colTotal.DataPropertyName = "Precio_Total";
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle6.Format = "C2";
            colTotal.DefaultCellStyle = dataGridViewCellStyle6;
            colTotal.FillWeight = 75F;
            colTotal.HeaderText = "Precio_Total";
            colTotal.MinimumWidth = 6;
            colTotal.Name = "colTotal";
            colTotal.ReadOnly = true;
            // 
            // FrmHistorialProveedores
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientInactiveCaption;
            ClientSize = new Size(815, 409);
            Controls.Add(btn_descargar);
            Controls.Add(btn_Atras);
            Controls.Add(btnNuevaCompra);
            Controls.Add(flowLayoutPanel1);
            Controls.Add(btnLimpiar);
            Controls.Add(btnFiltrar);
            Controls.Add(dtpHasta);
            Controls.Add(dtpDesde);
            Controls.Add(txtBuscar);
            Controls.Add(lblHasta);
            Controls.Add(lblDesde);
            Controls.Add(lblBuscar);
            Controls.Add(dgvHistorial);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 2, 3, 2);
            MinimizeBox = false;
            Name = "FrmHistorialProveedores";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Historial de Proveedores";
            Load += FrmHistorialProveedores_Load;
            ((System.ComponentModel.ISupportInitialize)dgvHistorial).EndInit();
            flowLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvHistorial;
        private Label lblBuscar;
        private Label lblDesde;
        private Label lblHasta;
        private TextBox txtBuscar;
        private DateTimePicker dtpDesde;
        private DateTimePicker dtpHasta;
        private Button btnFiltrar;
        private Button btnLimpiar;
        private FlowLayoutPanel flowLayoutPanel1;
        private PictureBox pictureBox1;
        private Button btnNuevaCompra;
        private Button btn_Atras;
        private Button btn_descargar;
        private DataGridViewTextBoxColumn colFecha;
        private DataGridViewTextBoxColumn colProveedor;
        private DataGridViewTextBoxColumn colProducto;
        private DataGridViewTextBoxColumn colKilos;
        private DataGridViewTextBoxColumn colUnidades;
        private DataGridViewTextBoxColumn colTotal;
    }
}