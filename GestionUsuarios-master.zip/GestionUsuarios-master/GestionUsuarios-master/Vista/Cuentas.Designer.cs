﻿namespace Vista
{
    partial class Cuentas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Cuentas));
            pnlCabecera = new Panel();
            cboFiltro = new ComboBox();
            lblTituloCuentas = new Label();
            dgvCuentas = new DataGridView();
            btnAgregarEntrada = new Button();
            lblAgregarEntrada = new Label();
            btnAgregarSalida = new Button();
            lblAgregarSalida = new Label();
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            button1 = new Button();
            pnlCabecera.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvCuentas).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pnlCabecera
            // 
            pnlCabecera.BackColor = Color.White;
            pnlCabecera.BorderStyle = BorderStyle.FixedSingle;
            pnlCabecera.Controls.Add(cboFiltro);
            pnlCabecera.Controls.Add(lblTituloCuentas);
            pnlCabecera.Location = new Point(46, 74);
            pnlCabecera.Name = "pnlCabecera";
            pnlCabecera.Size = new Size(400, 34);
            pnlCabecera.TabIndex = 0;
            // 
            // cboFiltro
            // 
            cboFiltro.DropDownStyle = ComboBoxStyle.DropDownList;
            cboFiltro.FormattingEnabled = true;
            cboFiltro.Items.AddRange(new object[] { "Ver todo" });
            cboFiltro.Location = new Point(245, 2);
            cboFiltro.Name = "cboFiltro";
            cboFiltro.Size = new Size(150, 28);
            cboFiltro.TabIndex = 1;
            // 
            // lblTituloCuentas
            // 
            lblTituloCuentas.AutoSize = true;
            lblTituloCuentas.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTituloCuentas.Location = new Point(5, 5);
            lblTituloCuentas.Name = "lblTituloCuentas";
            lblTituloCuentas.Size = new Size(80, 25);
            lblTituloCuentas.TabIndex = 0;
            lblTituloCuentas.Text = "Cuentas";
            // 
            // dgvCuentas
            // 
            dgvCuentas.AllowUserToAddRows = false;
            dgvCuentas.AllowUserToResizeColumns = false;
            dgvCuentas.BackgroundColor = Color.White;
            dgvCuentas.CellBorderStyle = DataGridViewCellBorderStyle.None;
            dgvCuentas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvCuentas.Location = new Point(46, 107);
            dgvCuentas.Name = "dgvCuentas";
            dgvCuentas.RowHeadersVisible = false;
            dgvCuentas.RowHeadersWidth = 51;
            dgvCuentas.Size = new Size(400, 380);
            dgvCuentas.TabIndex = 1;
            // 
            // btnAgregarEntrada
            // 
            btnAgregarEntrada.FlatAppearance.BorderColor = Color.ForestGreen;
            btnAgregarEntrada.FlatAppearance.BorderSize = 2;
            btnAgregarEntrada.FlatStyle = FlatStyle.Flat;
            btnAgregarEntrada.Font = new Font("Arial", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAgregarEntrada.ForeColor = Color.ForestGreen;
            btnAgregarEntrada.Location = new Point(486, 124);
            btnAgregarEntrada.Name = "btnAgregarEntrada";
            btnAgregarEntrada.Size = new Size(110, 45);
            btnAgregarEntrada.TabIndex = 2;
            btnAgregarEntrada.Text = "+";
            btnAgregarEntrada.UseVisualStyleBackColor = true;
            // 
            // lblAgregarEntrada
            // 
            lblAgregarEntrada.AutoSize = true;
            lblAgregarEntrada.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAgregarEntrada.ForeColor = Color.ForestGreen;
            lblAgregarEntrada.Location = new Point(486, 172);
            lblAgregarEntrada.Name = "lblAgregarEntrada";
            lblAgregarEntrada.Size = new Size(124, 20);
            lblAgregarEntrada.TabIndex = 3;
            lblAgregarEntrada.Text = "Agregar entrada";
            // 
            // btnAgregarSalida
            // 
            btnAgregarSalida.FlatAppearance.BorderColor = Color.Crimson;
            btnAgregarSalida.FlatAppearance.BorderSize = 2;
            btnAgregarSalida.FlatStyle = FlatStyle.Flat;
            btnAgregarSalida.Font = new Font("Arial", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAgregarSalida.ForeColor = Color.Crimson;
            btnAgregarSalida.Location = new Point(486, 234);
            btnAgregarSalida.Name = "btnAgregarSalida";
            btnAgregarSalida.Size = new Size(110, 45);
            btnAgregarSalida.TabIndex = 4;
            btnAgregarSalida.Text = "-";
            btnAgregarSalida.UseVisualStyleBackColor = true;
            // 
            // lblAgregarSalida
            // 
            lblAgregarSalida.AutoSize = true;
            lblAgregarSalida.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAgregarSalida.ForeColor = Color.Crimson;
            lblAgregarSalida.Location = new Point(486, 284);
            lblAgregarSalida.Name = "lblAgregarSalida";
            lblAgregarSalida.Size = new Size(110, 20);
            lblAgregarSalida.TabIndex = 5;
            lblAgregarSalida.Text = "Agregar salida";
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(92, 29, 36);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(677, 59);
            panel1.TabIndex = 6;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(110, 59);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 7;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.Menu;
            label1.Location = new Point(116, 9);
            label1.Name = "label1";
            label1.Size = new Size(273, 38);
            label1.TabIndex = 8;
            label1.Text = "ReGest | FINANZAS";
            // 
            // button1
            // 
            button1.Location = new Point(571, 12);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 9;
            button1.Text = "Atrás";
            button1.UseVisualStyleBackColor = true;
            // 
            // Cuentas
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientInactiveCaption;
            ClientSize = new Size(677, 525);
            Controls.Add(panel1);
            Controls.Add(lblAgregarSalida);
            Controls.Add(btnAgregarSalida);
            Controls.Add(lblAgregarEntrada);
            Controls.Add(btnAgregarEntrada);
            Controls.Add(dgvCuentas);
            Controls.Add(pnlCabecera);
            ForeColor = SystemColors.ControlText;
            FormBorderStyle = FormBorderStyle.None;
            Name = "Cuentas";
            Text = "Finanzas";
            pnlCabecera.ResumeLayout(false);
            pnlCabecera.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvCuentas).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel pnlCabecera;
        private Label lblTituloCuentas;
        private ComboBox cboFiltro;
        private DataGridView dgvCuentas;
        private Button btnAgregarEntrada;
        private Label lblAgregarEntrada;
        private Button btnAgregarSalida;
        private Label lblAgregarSalida;
        private Panel panel1;
        private PictureBox pictureBox1;
        private Button button1;
        private Label label1;
    }
}