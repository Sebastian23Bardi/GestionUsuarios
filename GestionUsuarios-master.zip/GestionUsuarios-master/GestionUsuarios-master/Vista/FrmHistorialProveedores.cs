﻿using System;
using System.Data;
using System.Windows.Forms;
using Logica;

namespace Vista
{
    public partial class FrmHistorialProveedores : Form
    {
        // Usar la clase de lógica correcta que adaptamos
        private HistorialProveedoresLogica logica = new HistorialProveedoresLogica();

        public FrmHistorialProveedores()
        {
            InitializeComponent();
        }

        private void FrmHistorialProveedores_Load(object sender, EventArgs e)
        {
            dtpDesde.Value = DateTime.Today.AddDays(-30);
            dtpHasta.Value = DateTime.Today;
            dgvHistorial.AutoGenerateColumns = false;

            CargarGrilla();
        }

        private void CargarGrilla()
        {
            try
            {
                string filtro = txtBuscar.Text.Trim();
                DateTime desde = dtpDesde.Value.Date;
                DateTime hasta = dtpHasta.Value.Date;

                // 1. Desvincular temporalmente el DataSource para forzar el redibujado
                dgvHistorial.DataSource = null;

                // 2. Traer el nuevo DataTable desde la lógica
                DataTable dt = logica.ConsultarHistorial(filtro, desde, hasta);

                // 3. Asignar el nuevo resultado
                dgvHistorial.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar el historial: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnFiltrar_Click(object sender, EventArgs e)
        {
            CargarGrilla();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtBuscar.Clear();
            dtpDesde.Value = DateTime.Today.AddDays(-30);
            dtpHasta.Value = DateTime.Today;
            CargarGrilla();
        }

        private void btnNuevaCompra_Click(object sender, EventArgs e)
        {
            using (FrmNuevaCompra modal = new FrmNuevaCompra())
            {
                // Solo recarga si FrmNuevaCompra terminó con DialogResult.OK
                if (modal.ShowDialog() == DialogResult.OK)
                {
                    CargarGrilla();
                }
            }
        }

        private void dgvHistorial_CellContentClick(object sender, DataGridViewCellEventArgs e) { }

        private void btn_Atras_Click(object sender, EventArgs e)
        {
            Proveedores prov = new Proveedores();
            prov.Show();
            this.Close();
        }
    }
}