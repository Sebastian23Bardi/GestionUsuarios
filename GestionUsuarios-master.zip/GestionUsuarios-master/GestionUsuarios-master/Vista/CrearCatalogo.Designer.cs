﻿namespace Vista
{
    partial class CrearCatalogo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CrearCatalogo));
            dataGridView1 = new DataGridView();
            Nombre = new DataGridViewTextBoxColumn();
            categoria = new DataGridViewTextBoxColumn();
            medida = new DataGridViewTextBoxColumn();
            tipo = new DataGridViewTextBoxColumn();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            textboxnombreproducto = new TextBox();
            btnagregareditar = new Button();
            btneliminarlimpiar = new Button();
            label4 = new Label();
            label5 = new Label();
            comboboxmedida = new ComboBox();
            comboboxcategoria = new ComboBox();
            label6 = new Label();
            comboboxtipoproducto = new ComboBox();
            btnguardar = new Button();
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            btn_atras = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToResizeColumns = false;
            dataGridView1.AllowUserToResizeRows = false;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.BackgroundColor = SystemColors.GradientInactiveCaption;
            dataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Nombre, categoria, medida, tipo });
            dataGridView1.Location = new Point(13, 160);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.ScrollBars = ScrollBars.Vertical;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new Size(892, 280);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellClick += dataGridView1_CellClick;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            dataGridView1.SelectionChanged += dataGridView1_SelectionChanged;
            // 
            // Nombre
            // 
            Nombre.HeaderText = "Nombre de producto";
            Nombre.MinimumWidth = 6;
            Nombre.Name = "Nombre";
            // 
            // categoria
            // 
            categoria.HeaderText = "Categoría";
            categoria.MinimumWidth = 6;
            categoria.Name = "categoria";
            // 
            // medida
            // 
            medida.HeaderText = "Medida";
            medida.MinimumWidth = 6;
            medida.Name = "medida";
            // 
            // tipo
            // 
            tipo.HeaderText = "Tipo de pruducto";
            tipo.MinimumWidth = 6;
            tipo.Name = "tipo";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(22, 93);
            label1.Name = "label1";
            label1.Size = new Size(67, 20);
            label1.TabIndex = 1;
            label1.Text = "Nombre:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10.8F);
            label2.Location = new Point(22, 131);
            label2.Name = "label2";
            label2.Size = new Size(77, 20);
            label2.TabIndex = 2;
            label2.Text = "Categoría:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10.8F);
            label3.Location = new Point(312, 96);
            label3.Name = "label3";
            label3.Size = new Size(63, 20);
            label3.TabIndex = 3;
            label3.Text = "Medida:";
            // 
            // textboxnombreproducto
            // 
            textboxnombreproducto.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textboxnombreproducto.Location = new Point(90, 94);
            textboxnombreproducto.Name = "textboxnombreproducto";
            textboxnombreproducto.Size = new Size(199, 27);
            textboxnombreproducto.TabIndex = 4;
            // 
            // btnagregareditar
            // 
            btnagregareditar.BackColor = Color.FromArgb(92, 29, 36);
            btnagregareditar.ForeColor = SystemColors.Menu;
            btnagregareditar.Location = new Point(583, 87);
            btnagregareditar.Name = "btnagregareditar";
            btnagregareditar.Size = new Size(97, 36);
            btnagregareditar.TabIndex = 7;
            btnagregareditar.Text = "Agregar";
            btnagregareditar.UseVisualStyleBackColor = false;
            btnagregareditar.Click += btnagregareditar_Click;
            // 
            // btneliminarlimpiar
            // 
            btneliminarlimpiar.BackColor = Color.FromArgb(92, 29, 36);
            btneliminarlimpiar.ForeColor = SystemColors.Info;
            btneliminarlimpiar.Location = new Point(696, 86);
            btneliminarlimpiar.Name = "btneliminarlimpiar";
            btneliminarlimpiar.Size = new Size(97, 36);
            btneliminarlimpiar.TabIndex = 8;
            btneliminarlimpiar.Text = "Eliminar";
            btneliminarlimpiar.UseVisualStyleBackColor = false;
            btneliminarlimpiar.Click += btneliminarlimpiar_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = SystemColors.Menu;
            label4.Location = new Point(116, 7);
            label4.Name = "label4";
            label4.Size = new Size(375, 32);
            label4.TabIndex = 9;
            label4.Text = "ReGest | Catálogo de productos";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Gainsboro;
            label5.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = SystemColors.ControlText;
            label5.Location = new Point(13, 52);
            label5.Name = "label5";
            label5.Size = new Size(173, 25);
            label5.TabIndex = 10;
            label5.Text = "Datos del producto";
            label5.Click += label5_Click;
            // 
            // comboboxmedida
            // 
            comboboxmedida.Font = new Font("Segoe UI", 10.8F);
            comboboxmedida.FormattingEnabled = true;
            comboboxmedida.Location = new Point(384, 94);
            comboboxmedida.Name = "comboboxmedida";
            comboboxmedida.Size = new Size(84, 27);
            comboboxmedida.TabIndex = 11;
            // 
            // comboboxcategoria
            // 
            comboboxcategoria.Font = new Font("Segoe UI", 10.8F);
            comboboxcategoria.FormattingEnabled = true;
            comboboxcategoria.Location = new Point(102, 129);
            comboboxcategoria.Name = "comboboxcategoria";
            comboboxcategoria.Size = new Size(115, 27);
            comboboxcategoria.TabIndex = 12;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 10.8F);
            label6.Location = new Point(221, 131);
            label6.Name = "label6";
            label6.Size = new Size(128, 20);
            label6.TabIndex = 13;
            label6.Text = "Tipo de producto:";
            // 
            // comboboxtipoproducto
            // 
            comboboxtipoproducto.Font = new Font("Segoe UI", 10.8F);
            comboboxtipoproducto.FormattingEnabled = true;
            comboboxtipoproducto.Location = new Point(362, 129);
            comboboxtipoproducto.Name = "comboboxtipoproducto";
            comboboxtipoproducto.Size = new Size(143, 27);
            comboboxtipoproducto.TabIndex = 14;
            // 
            // btnguardar
            // 
            btnguardar.BackColor = Color.FromArgb(92, 29, 36);
            btnguardar.ForeColor = SystemColors.Info;
            btnguardar.Location = new Point(809, 89);
            btnguardar.Name = "btnguardar";
            btnguardar.Size = new Size(94, 32);
            btnguardar.TabIndex = 15;
            btnguardar.Text = "Guardar";
            btnguardar.UseVisualStyleBackColor = false;
            btnguardar.Click += btnguardar_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(92, 29, 36);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(btn_atras);
            panel1.Controls.Add(label4);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(3, 2, 3, 2);
            panel1.Name = "panel1";
            panel1.Size = new Size(915, 50);
            panel1.TabIndex = 16;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, 2);
            pictureBox1.Margin = new Padding(3, 2, 3, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(102, 46);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 17;
            pictureBox1.TabStop = false;
            // 
            // btn_atras
            // 
            btn_atras.Location = new Point(822, 16);
            btn_atras.Margin = new Padding(3, 2, 3, 2);
            btn_atras.Name = "btn_atras";
            btn_atras.Size = new Size(82, 22);
            btn_atras.TabIndex = 10;
            btn_atras.Text = "Atrás";
            btn_atras.UseVisualStyleBackColor = true;
            btn_atras.Click += btn_atras_Click;
            // 
            // CrearCatalogo
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientInactiveCaption;
            ClientSize = new Size(915, 446);
            Controls.Add(panel1);
            Controls.Add(btnguardar);
            Controls.Add(comboboxtipoproducto);
            Controls.Add(label6);
            Controls.Add(comboboxcategoria);
            Controls.Add(comboboxmedida);
            Controls.Add(label5);
            Controls.Add(btneliminarlimpiar);
            Controls.Add(btnagregareditar);
            Controls.Add(textboxnombreproducto);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dataGridView1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "CrearCatalogo";
            StartPosition = FormStartPosition.CenterScreen;
            Load += CrearCatalogo_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox textboxnombreproducto;
        private Button btnagregareditar;
        private Button btneliminarlimpiar;
        private Label label4;
        private Label label5;
        private ComboBox comboboxmedida;
        private ComboBox comboboxcategoria;
        private Label label6;
        private ComboBox comboboxtipoproducto;
        private Button btnguardar;
        private DataGridViewTextBoxColumn Nombre;
        private DataGridViewTextBoxColumn categoria;
        private DataGridViewTextBoxColumn medida;
        private DataGridViewTextBoxColumn tipo;
        private Panel panel1;
        private Button btn_atras;
        private PictureBox pictureBox1;
    }
}